<?php
include_once('../inc/db_con.inc.php');
include_once('functions.php');

$api = $_POST['api'];
if(isset($api)){
	switch($api){
		case 'register':
			include_once('register.php');
		break;

		case 'login':
			include_once('login.php');
		break;	

		case 'get_current_user':
			include_once('get_current_user.php');
		break;
		
		case 'create_group':
			include_once('create_group.php');
		break;

		case 'get_group_members':
			include_once('get_group_members.php');
		break;

		case 'get_group_info':
			include_once('get_group_info.php');
		break;

		case 'get_user_groups':
			include_once('get_user_groups.php');
		break;

		case 'delete_member':
			include_once('delete_member.php');
		break;

		case 'add_member_to_group':
			include_once('add_member_to_group.php');
		break;

		case 'create_event':
			include_once('create_event.php');
		break;	

		case 'request_group_access':
			include_once('request_group_access.php');
		break;	
		
	}
	
}else{
	echo "INVALID URL";	
}


?>